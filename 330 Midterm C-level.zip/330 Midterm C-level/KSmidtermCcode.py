# Katie Sheehan Midterm C-Level Code

import syntaxchecker_lib as sc

def main():
    ifile= open("CLevel.java","r")
    ccode = ifile.readlines() 
    ccode = "".join(ccode)
    #print (ccode + "\n")

    ccode = sc.removecomments(ccode)
    ccode = sc.removeimports(ccode) 
    ccode = sc.removewhitespace(ccode)
    ccode = sc.classconstruction(ccode)
    ccode = sc.varifymain(ccode)
    ccode = sc.assignment(ccode)
    ccode = sc.arithmetic(ccode)
    ccode = sc.output(ccode)
    print(ccode)
    if ccode == "":
        print("your code is fully compiled")
    else:
        print("syntax error in code")



main()



