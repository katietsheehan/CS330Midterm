/*
Code to be syntax-checked for C-level Midterm project grade
*/

import java.io.*;
//only one import statement!

class CLevel{

    public static void main (String [] args){
        //now we are in main
        String stringtrue = "String";
        int x = 5;
        System.out.println("It is true that string has 6 letters");
        boolean t = false;
        x = x + 3;
        System.out.println(x);
        
        /*
        If there are other things that you want to test,
        here is a good place for them.
        */

    }

}