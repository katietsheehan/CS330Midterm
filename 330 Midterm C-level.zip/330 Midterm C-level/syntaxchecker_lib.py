#Katie Sheehan Syntax Checker Library C-Code
#print statements removed after testing testing
import re

def removecomments(code):
    #remove single line comments
    code = re.sub(r"//.+", "", code)
    #print (code + "\n")

    #remove muliple line comments
    code = re.sub(r"/\*([\s\S]*?)\*/","",code)
    #print (code + "\n")
    return(code)


def removeimports(code):
    #remove import statements
    code = re.sub(r"import.+;", "", code)
    #print (code + "\n")
    return(code)

def removewhitespace(code):
    #remove extra white space (more than one space and newlines)
    code = re.sub(r"\s{2,}", "", code)
    #print (code + "\n")
    return(code)


def classconstruction(code):
    match = re.search(r"class\s\w+{", code)
    if match:
        code = re.sub(r"class\s\w+{","", code)
        code = re.sub(r"}$","",code)
##    else:
##        raise Exception('Incorrect Syntax')
    return(code)
                     
def varifymain(code):
    match = re.search(r"public\sstatic\svoid\smain.+{", code)
    if match:
        code = re.sub(r"public\sstatic\svoid\smain.+{","", code)
        code = re.sub(r"}$","",code)
##    else:
##        raise Exception('Incorrect Syntax')
    return(code)

def assignment(code):
    lh = re.search(r"(String|int|boolean)\s\w+",code)
    if lh:
        rh = re.search(r"=\s(\"\w+\"|\d|\w+);", code)
        if rh:
            code = re.sub(r"(String|int|boolean)\s\w+","", code)
            code = re.sub(r"=\s(\"\w+\"|\d|\w+);","", code)
            code = re.sub(r"}$","",code)
##    else:
##        raise Exception('Incorrect Syntax')
   
    return (code)

def arithmetic(code):
    match = re.search(r"\w+\s=\s\w+\s(\+|\-|\*|\/)\s\w+;",code)
    if match:
        code = re.sub(r"\w+\s=\s\w+\s(\+|\-|\*|\/)\s\w+;", "", code)
##    else:
##        raise Exception('Incorrect Syntax')
    return(code)
        
                        
def output(code):
    code = re.sub(r"\s{1,}", "", code)
    #match String outputs
    match = re.search(r"System\.out\.println\(\"\w+\"\);", code)
    if match:
        code = re.sub(r"System\.out\.println\(\"\w+\"\);", "", code)
##    else:
##        raise Exception('Incorrect Syntax')
    
    #match Variable outputs
    match2 = re.search(r"System\.out\.println\(\w+\);",code)
    if match2:
        code = re.sub(r"System\.out\.println\(\w+\);", "", code)
##    else:
##        raise Exception('Incorrect Syntax')
    return(code)
